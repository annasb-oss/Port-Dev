import React from 'react';
import { TECH_STACK } from '../utils/portfolio-data';
import { TechIconRenderer } from './TechIcons';
import { ShieldCheck, Cpu, ExternalLink } from 'lucide-react';

export default function TechStackSection() {
  return (
    <section
      id="pilha-tecnica"
      className="relative z-10 w-full bg-black px-4 sm:px-8 md:px-12 lg:px-16 py-16 md:py-24 text-white scroll-mt-20"
    >
      <div className="max-w-6xl mx-auto">
        {/* Stack Tecnológica Header */}
        <div className="flex flex-col items-center text-center mb-10">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-400 text-xs sm:text-sm font-semibold uppercase tracking-wider mb-3">
            <Cpu className="w-4 h-4 text-blue-400" />
            <span>Ferramentas & Tecnologias</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white uppercase font-sans">
            Stack <span className="text-[#3b82f6]">Tecnológica</span>
          </h2>
          <p className="mt-2 text-sm sm:text-base text-zinc-400 max-w-2xl">
            As tecnologias fundamentais que utilizo no desenvolvimento e nos estudos diários de back-end.
          </p>
        </div>

        {/* Tech Stack Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {TECH_STACK.map((tech, idx) => {
              const isCenteredTrailingCard =
                TECH_STACK.length % 3 === 1 && idx === TECH_STACK.length - 1;
              return (
                <div
                  key={tech.id}
                  data-testid={`stack-${tech.id}`}
                  className={`group relative p-6 rounded-3xl bg-[#141414] border border-zinc-800/90 hover:border-blue-500/50 transition-all duration-300 shadow-lg hover:shadow-[0_10px_30px_rgba(59,130,246,0.12)] flex flex-col justify-between ${
                    isCenteredTrailingCard ? 'md:col-span-2 lg:col-span-3 lg:max-w-sm lg:mx-auto w-full' : ''
                  }`}
                >
                  <div>
                    {/* Header with icon and level pill */}
                    <div className="flex items-center justify-between mb-4">
                      <div className="w-12 h-12 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center p-2.5 group-hover:scale-110 group-hover:border-zinc-700 transition duration-300">
                        <TechIconRenderer iconName={tech.iconName} className="w-7 h-7" />
                      </div>
                      <span
                        className={`text-xs px-2.5 py-1 rounded-full font-medium border ${tech.badgeColor}`}
                      >
                        {tech.level}
                      </span>
                    </div>

                    {/* Tech Title & Optional Alias */}
                    <div className="mb-2">
                      <h3 className="text-xl font-bold text-white group-hover:text-blue-400 transition">
                        {tech.name}
                      </h3>
                      {tech.alias && (
                        <span className="text-xs font-semibold text-zinc-500 block mt-0.5">
                          ({tech.alias})
                        </span>
                      )}
                    </div>

                    {/* Category tag */}
                    <span className="text-xs text-blue-400/90 font-medium uppercase tracking-wider block mb-3">
                      {tech.category}
                    </span>

                    {/* Description */}
                    <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed">
                      {tech.description}
                    </p>
                  </div>

                  {/* Bottom indicator or external access link */}
                  {tech.url ? (
                    <div className="mt-6 pt-4 border-t border-zinc-800/60">
                      <a
                        href={tech.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        aria-label={`Acessar ${tech.name} em ${tech.url}`}
                        className="inline-flex items-center justify-between gap-2 w-full px-3.5 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-700/80 hover:border-blue-500/60 text-xs font-semibold text-white transition"
                      >
                        <span className="truncate">{tech.linkLabel ?? tech.url}</span>
                        <ExternalLink className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                      </a>
                    </div>
                  ) : (
                    <div className="mt-6 pt-4 border-t border-zinc-800/60 flex items-center justify-between text-xs text-zinc-500">
                      <span className="flex items-center gap-1.5">
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                        Boas Práticas
                      </span>
                      <span className="text-zinc-600 font-mono text-[10px]">BACKEND-STACK</span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
      </div>
    </section>
  );
}
