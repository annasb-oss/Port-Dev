import React, { useMemo } from 'react';

interface LightBeam {
  id: number;
  top: string;
  left: string;
  width: number;
  angle: number;
  duration: string;
  delay: string;
  opacity: number;
}

const DIAGONAL_BEAMS: LightBeam[] = [
  { id: 1, top: '14%', left: '8%', width: 220, angle: 34, duration: '9s', delay: '-1.5s', opacity: 0.45 },
  { id: 2, top: '64%', left: '12%', width: 170, angle: 36, duration: '11s', delay: '-4.2s', opacity: 0.35 },
  { id: 3, top: '20%', left: '66%', width: 240, angle: 144, duration: '10s', delay: '-2.8s', opacity: 0.42 },
  { id: 4, top: '72%', left: '72%', width: 185, angle: 142, duration: '12s', delay: '-6.0s', opacity: 0.35 },
  { id: 5, top: '42%', left: '82%', width: 150, angle: 146, duration: '8.5s', delay: '-0.8s', opacity: 0.3 },
];

export default function AboutCosmicBackground() {
  const stars = useMemo(() => {
    return Array.from({ length: 72 }).map((_, i) => {
      const top = `${((i * 41 + 9) % 94) + 3}%`;
      const left = `${((i * 59 + 11) % 96) + 2}%`;
      const isBright = i % 6 === 0;
      const isBlue = i % 2 === 0;
      const size = isBright ? 2.4 : i % 3 === 0 ? 1.8 : 1.2;
      const opacity = isBright ? 0.85 : isBlue ? 0.55 : 0.4;
      const duration = `${2.6 + ((i * 17) % 30) / 10}s`;
      const delay = `${((i * 13) % 24) / 10}s`;
      return { id: i, top, left, size, opacity, duration, delay, isBright, isBlue };
    });
  }, []);

  return (
    <div
      aria-hidden="true"
      data-testid="about-cosmic-bg"
      className="pointer-events-none absolute inset-0 z-0 overflow-hidden bg-[#030817] select-none"
    >
      {/* Deep navy-to-black base & intense soft blue side radial lighting */}
      <div
        className="absolute inset-0"
        style={{
          background: [
            'radial-gradient(ellipse 46% 68% at 4% 50%, rgba(37, 99, 235, 0.36) 0%, rgba(29, 78, 216, 0.16) 44%, rgba(3, 8, 23, 0) 78%)',
            'radial-gradient(ellipse 46% 68% at 96% 48%, rgba(37, 99, 235, 0.34) 0%, rgba(30, 64, 175, 0.15) 44%, rgba(3, 8, 23, 0) 78%)',
            'radial-gradient(circle at 50% 54%, rgba(30, 64, 175, 0.22) 0%, rgba(15, 23, 42, 0.18) 38%, rgba(3, 8, 23, 0) 70%)',
            'linear-gradient(180deg, #020612 0%, #030817 50%, #020510 100%)',
          ].join(', '),
        }}
      />

      {/* Twinkling stars & luminous cosmic dust */}
      {stars.map((star) => (
        <span
          key={star.id}
          className={`absolute rounded-full ${
            star.isBright
              ? 'bg-white shadow-[0_0_8px_rgba(147,197,253,0.9)] animate-aurora-twinkle-bright'
              : star.isBlue
                ? 'bg-blue-300 shadow-[0_0_5px_rgba(96,165,250,0.6)] animate-aurora-twinkle'
                : 'bg-slate-200 animate-aurora-twinkle'
          }`}
          style={{
            top: star.top,
            left: star.left,
            width: `${star.size}px`,
            height: `${star.size}px`,
            opacity: star.opacity,
            animationDuration: star.duration,
            animationDelay: star.delay,
          }}
        />
      ))}

      {/* Subtle diagonal light streaks matching the cosmic portfolio reference */}
      {DIAGONAL_BEAMS.map((beam) => (
        <div
          key={beam.id}
          className="absolute"
          style={{
            top: beam.top,
            left: beam.left,
            transform: `rotate(${beam.angle}deg)`,
          }}
        >
          <div
            className="about-diagonal-beam h-[1.5px] rounded-full"
            style={
              {
                width: `${beam.width}px`,
                '--beam-opacity': beam.opacity,
                background:
                  'linear-gradient(90deg, rgba(59,130,246,0) 0%, rgba(96,165,250,0.45) 55%, rgba(255,255,255,0.9) 100%)',
                boxShadow: '0 0 8px rgba(96, 165, 250, 0.35)',
                animationDuration: beam.duration,
                animationDelay: beam.delay,
              } as React.CSSProperties
            }
          />
        </div>
      ))}
    </div>
  );
}
