export interface LensPoint {
  x: number;
  y: number;
}

export interface LensBounds {
  width: number;
  height: number;
}

/**
 * Clamps pointer coordinates inside the portrait stage so the spotlight mask
 * stays well-formed even near edges.
 */
export function clampLensPoint(
  clientX: number,
  clientY: number,
  rectLeft: number,
  rectTop: number,
  bounds: LensBounds
): LensPoint {
  const safeW = Math.max(1, bounds.width);
  const safeH = Math.max(1, bounds.height);
  const rawX = clientX - rectLeft;
  const rawY = clientY - rectTop;
  return {
    x: Math.min(safeW, Math.max(0, Math.round(rawX))),
    y: Math.min(safeH, Math.max(0, Math.round(rawY))),
  };
}

/**
 * Computes a proportional spotlight radius (~22% of portrait width, clamped to
 * 88px..132px) so hovering reveals a focused body area of Catwoman's costume
 * while keeping Ana clearly visible.
 */
export function computeLensRadius(stageWidth: number): number {
  if (!Number.isFinite(stageWidth) || stageWidth <= 0) {
    return 108;
  }
  return Math.round(Math.min(132, Math.max(88, stageWidth * 0.22)));
}

/**
 * On touch tap, toggles off if tapping close to the already-active spotlight;
 * otherwise repositions the spotlight to the newly tapped body part.
 */
export function shouldHideTouchLens(
  isCurrentlyActive: boolean,
  currentPoint: LensPoint,
  tappedPoint: LensPoint,
  thresholdPx: number = 34
): boolean {
  if (!isCurrentlyActive) return false;
  const dx = currentPoint.x - tappedPoint.x;
  const dy = currentPoint.y - tappedPoint.y;
  return Math.hypot(dx, dy) <= thresholdPx;
}
