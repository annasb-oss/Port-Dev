import React, { useState } from 'react';
import {
  GraduationCap,
  Terminal,
  Code2,
  Globe,
  BookOpen,
  Award,
  Languages,
  Cpu,
  Clock,
  ExternalLink,
  Calendar,
} from 'lucide-react';
import {
  EDUCATION_TIMELINE,
  EXPERIENCE_TIMELINE,
  TimelineEntry,
  TimelineIconType,
} from '../utils/portfolio-data';
import { TechIconRenderer, GitHubIcon } from './TechIcons';

function TimelineEntryIcon({ type }: { type: TimelineIconType }) {
  const iconClass = 'w-4 h-4 text-[#38bdf8]';
  switch (type) {
    case 'university':
      return <GraduationCap className={iconClass} aria-hidden="true" />;
    case 'dio':
      return <Terminal className={iconClass} aria-hidden="true" />;
    case 'freecodecamp':
      return <Code2 className={iconClass} aria-hidden="true" />;
    case 'bradesco':
      return <Globe className={iconClass} aria-hidden="true" />;
    case 'harvard':
      return <BookOpen className={iconClass} aria-hidden="true" />;
    case 'unimar-extra':
      return <Award className={iconClass} aria-hidden="true" />;
    case 'duolingo':
      return <Languages className={iconClass} aria-hidden="true" />;
    case 'github':
      return <GitHubIcon className="w-4 h-4 text-slate-200" />;
    case 'backend':
      return <Cpu className={iconClass} aria-hidden="true" />;
    case 'placeholder':
      return <Clock className="w-4 h-4 text-slate-400" aria-hidden="true" />;
    default:
      return <Code2 className={iconClass} aria-hidden="true" />;
  }
}

const TECH_LABEL_MAP: Record<string, string> = {
  java: 'Java',
  spring: 'Spring Boot',
  postgres: 'PostgreSQL',
  mysql: 'MySQL',
  docker: 'Docker',
  junit: 'JUnit',
  github: 'GitHub',
};

interface TimelineColumnProps {
  title: string;
  entries: TimelineEntry[];
  activeId: string;
  onSelect: (id: string) => void;
  testIdPrefix: string;
}

function TimelineColumn({
  title,
  entries,
  activeId,
  onSelect,
  testIdPrefix,
}: TimelineColumnProps) {
  return (
    <div className="flex flex-col">
      <h3 className="text-xl sm:text-2xl font-bold tracking-tight text-white mb-6 pl-12">
        {title}
      </h3>

      <div className="relative flex flex-col gap-5">
        {/* Continuous vertical timeline rail with subtle downward shimmer */}
        <div
          aria-hidden="true"
          className="pointer-events-none absolute left-[17px] top-4 bottom-4 w-px bg-gradient-to-b from-[#00abf0]/50 via-slate-700/75 to-slate-800/30 overflow-hidden"
        >
          <div className="timeline-line-glow w-full h-24 bg-gradient-to-b from-transparent via-[#38bdf8] to-transparent" />
        </div>

        {entries.map((entry) => {
          const isActive = activeId === entry.id;
          const isPlaceholder = Boolean(entry.isPlaceholder);

          return (
            <div
              key={entry.id}
              data-testid={`${testIdPrefix}-item-${entry.id}`}
              className="group relative pl-12"
            >
              {/* Numbered circular marker */}
              <button
                type="button"
                onClick={() => onSelect(entry.id)}
                aria-pressed={isActive}
                aria-label={`Selecionar ${entry.institution}`}
                data-testid={`${testIdPrefix}-marker-${entry.id}`}
                data-active={isActive ? 'true' : 'false'}
                className={`absolute left-0 top-5 z-10 w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold tabular-nums border transition-all duration-200 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#38bdf8] ${
                  isActive
                    ? 'bg-white text-[#040c18] border-white shadow-[0_0_16px_rgba(255,255,255,0.3)] scale-105'
                    : isPlaceholder
                      ? 'bg-[#0b1322] text-slate-500 border-slate-700/70 group-hover:border-slate-500 group-hover:text-slate-300'
                      : 'bg-[#121c2d] text-slate-400 border-slate-700/90 group-hover:border-[#00abf0]/70 group-hover:text-white'
                }`}
              >
                {entry.numberLabel}
              </button>

              {/* Card Container */}
              <div
                onClick={() => onSelect(entry.id)}
                className={`relative rounded-xl border p-5 transition-all duration-200 ${
                  isPlaceholder
                    ? isActive
                      ? 'border-dashed border-slate-500/80 bg-[#071323]/80'
                      : 'border-dashed border-slate-700/75 bg-[#050f1d]/65 hover:border-slate-500/70'
                    : isActive
                      ? 'border-[#00abf0]/80 bg-[#081a30]/95 shadow-[0_10px_28px_rgba(0,171,240,0.12)]'
                      : 'border-[#00abf0]/30 bg-[#061325]/85 hover:border-[#00abf0]/65 hover:bg-[#08192e]/90 hover:-translate-y-0.5'
                }`}
              >
                {/* Header Row: Icon + Institution/Title (left) + Date/Period (right) */}
                <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2 sm:gap-4">
                  <div className="flex items-start gap-2.5 min-w-0">
                    <span
                      className={`mt-0.5 w-7 h-7 rounded-md border flex items-center justify-center shrink-0 ${
                        isPlaceholder
                          ? 'bg-slate-900/70 border-slate-700/60'
                          : 'bg-[#0a213b] border-[#00abf0]/25'
                      }`}
                    >
                      <TimelineEntryIcon type={entry.icon} />
                    </span>

                    <div className="min-w-0">
                      <h4
                        className={`text-base sm:text-[17px] font-bold leading-snug ${
                          isPlaceholder ? 'text-slate-300' : 'text-white'
                        }`}
                      >
                        {entry.institution}
                      </h4>
                    </div>
                  </div>

                  {entry.period && (
                    <span className="inline-flex items-center gap-1.5 text-xs font-medium text-[#38bdf8] tabular-nums shrink-0 sm:pt-1 whitespace-nowrap">
                      <Calendar className="w-3.5 h-3.5 opacity-80 shrink-0" aria-hidden="true" />
                      <span>{entry.period}</span>
                    </span>
                  )}
                </div>

                {/* Course / Subtitle */}
                <p
                  className={`mt-2.5 text-sm font-medium leading-relaxed ${
                    isPlaceholder ? 'text-slate-400' : 'text-slate-200'
                  }`}
                >
                  {entry.courseOrRole}
                </p>

                {/* Description */}
                {entry.description && (
                  <p className="mt-1.5 text-xs sm:text-[13px] text-slate-400 leading-relaxed">
                    {entry.description}
                  </p>
                )}

                {/* Technology icons (when real technologies apply) */}
                {entry.techIcons && entry.techIcons.length > 0 && (
                  <div className="mt-3 flex flex-wrap items-center gap-2">
                    {entry.techIcons.map((tech) => (
                      <span
                        key={tech}
                        className="inline-flex items-center gap-1.5 rounded-[4px] border border-slate-700/70 bg-[#0b1b30]/80 px-2 py-0.5 text-[11px] font-medium text-slate-300"
                      >
                        <TechIconRenderer iconName={tech} className="w-3.5 h-3.5" />
                        <span>{TECH_LABEL_MAP[tech] ?? tech}</span>
                      </span>
                    ))}
                  </div>
                )}

                {/* Bottom row: Discrete category/status tags + optional GitHub repository link */}
                {(entry.tags?.length || entry.linkUrl) && (
                  <div className="mt-3.5 pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2">
                    <div className="flex flex-wrap items-center gap-1.5">
                      {entry.tags?.map((tag) => (
                        <span
                          key={tag}
                          className={`rounded-[4px] border px-2 py-0.5 text-[11px] font-medium whitespace-nowrap ${
                            tag === 'Em andamento' || tag === 'Em Estudo'
                              ? 'border-[#00abf0]/35 bg-[#00abf0]/10 text-[#7dd3fc]'
                              : tag === 'Concluído'
                                ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-300'
                                : 'border-slate-700/80 bg-slate-800/50 text-slate-300'
                          }`}
                        >
                          {tag}
                        </span>
                      ))}
                    </div>

                    {entry.linkUrl && (
                      <a
                        href={entry.linkUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={(e) => e.stopPropagation()}
                        className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#38bdf8] hover:text-white transition-colors whitespace-nowrap"
                      >
                        <span>{entry.linkLabel ?? 'Ver no GitHub'}</span>
                        <ExternalLink className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                      </a>
                    )}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default function ExperiencesSection() {
  const [activeEducationId, setActiveEducationId] = useState<string>(
    EDUCATION_TIMELINE[0]?.id ?? ''
  );
  const [activeExperienceId, setActiveExperienceId] = useState<string>(
    EXPERIENCE_TIMELINE[0]?.id ?? ''
  );

  return (
    <section
      id="experiencias"
      aria-labelledby="experiencias-heading"
      className="relative z-10 w-full bg-[#040c18] px-5 sm:px-8 md:px-12 lg:px-16 py-20 md:py-24 text-white overflow-hidden scroll-mt-14 border-t border-sky-950/60"
    >
      {/* Subtle deep navy gradient illumination */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            'radial-gradient(ellipse 75% 45% at 50% 0%, rgba(0, 171, 240, 0.08) 0%, rgba(4, 12, 24, 0) 70%), radial-gradient(circle at 12% 80%, rgba(14, 165, 233, 0.06) 0%, rgba(4, 12, 24, 0) 55%)',
        }}
      />

      {/* Discrete Topographic Contour Texture (seamless full-canvas organic contours) */}
      <svg
        aria-hidden="true"
        viewBox="0 0 1440 1100"
        preserveAspectRatio="xMidYMid slice"
        className="pointer-events-none absolute inset-0 w-full h-full opacity-[0.095]"
      >
        <g fill="none" stroke="#38bdf8" strokeWidth="1">
          <path d="M-80 140 C 180 60, 420 240, 720 150 C 1020 60, 1240 210, 1520 120" />
          <path d="M-80 185 C 190 105, 430 280, 730 190 C 1030 100, 1250 250, 1520 165" strokeOpacity="0.8" />
          <path d="M-80 235 C 210 155, 445 320, 745 235 C 1045 150, 1265 290, 1520 215" strokeOpacity="0.6" />
          <path d="M-80 290 C 230 215, 465 365, 765 285 C 1065 205, 1280 335, 1520 270" strokeOpacity="0.45" />

          <path d="M90 520 C 160 400, 380 370, 470 470 C 560 570, 460 720, 290 710 C 130 700, 35 620, 90 520 Z" />
          <path d="M135 530 C 190 435, 355 415, 425 490 C 495 565, 420 675, 290 668 C 165 660, 95 605, 135 530 Z" strokeOpacity="0.75" />
          <path d="M180 542 C 220 475, 330 460, 380 512 C 430 564, 380 635, 290 630 C 205 625, 155 585, 180 542 Z" strokeOpacity="0.55" />

          <path d="M890 430 C 1010 320, 1260 340, 1340 460 C 1420 580, 1320 740, 1140 735 C 960 730, 790 525, 890 430 Z" stroke="#7dd3fc" />
          <path d="M945 448 C 1035 365, 1225 380, 1285 472 C 1345 564, 1270 688, 1135 684 C 1000 680, 870 520, 945 448 Z" stroke="#7dd3fc" strokeOpacity="0.7" />
          <path d="M1000 468 C 1060 412, 1190 422, 1230 485 C 1270 548, 1220 632, 1130 630 C 1040 628, 950 515, 1000 468 Z" stroke="#7dd3fc" strokeOpacity="0.5" />

          <path d="M-60 880 C 220 790, 490 950, 790 865 C 1090 780, 1290 930, 1520 845" />
          <path d="M-60 935 C 235 845, 505 1000, 805 920 C 1105 840, 1300 980, 1520 900" strokeOpacity="0.7" />
          <path d="M-60 995 C 250 905, 520 1055, 820 975 C 1120 895, 1315 1035, 1520 960" strokeOpacity="0.45" />
        </g>
      </svg>

      <div className="relative z-10 max-w-6xl mx-auto">
        {/* Centered Header matching reference style */}
        <div className="text-center mb-14">
          <h2
            id="experiencias-heading"
            className="text-3xl sm:text-4xl lg:text-[2.65rem] font-extrabold tracking-tight text-white font-sans text-balance"
          >
            Minhas <span className="text-[#00abf0]">Experiências</span>
          </h2>
          <p className="mt-3 text-sm sm:text-base text-slate-400 max-w-2xl mx-auto">
            Formação acadêmica, cursos complementares, projetos práticos e evolução contínua no desenvolvimento Back-end.
          </p>
        </div>

        {/* Two-Column Timeline */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-12 items-start">
          <TimelineColumn
            title="Formação e Estudos"
            entries={EDUCATION_TIMELINE}
            activeId={activeEducationId}
            onSelect={setActiveEducationId}
            testIdPrefix="education"
          />

          <TimelineColumn
            title="Experiência e Projetos"
            entries={EXPERIENCE_TIMELINE}
            activeId={activeExperienceId}
            onSelect={setActiveExperienceId}
            testIdPrefix="experience"
          />
        </div>
      </div>
    </section>
  );
}
