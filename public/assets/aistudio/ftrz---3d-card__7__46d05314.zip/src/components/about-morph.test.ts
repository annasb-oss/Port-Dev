import test from 'node:test';
import assert from 'node:assert/strict';
import {
  clampLensPoint,
  computeLensRadius,
  shouldHideTouchLens,
} from './about-morph';

test('clampLensPoint converts client coordinates to clamped stage coordinates', () => {
  const inside = clampLensPoint(250, 310, 100, 150, { width: 500, height: 625 });
  assert.deepEqual(inside, { x: 150, y: 160 });

  const clamped = clampLensPoint(80, 900, 100, 150, { width: 500, height: 625 });
  assert.deepEqual(clamped, { x: 0, y: 625 });
});

test('computeLensRadius scales proportionally and stays within comfortable bounds', () => {
  assert.equal(computeLensRadius(300), 88);
  assert.equal(computeLensRadius(500), 110);
  assert.equal(computeLensRadius(720), 132);
  assert.equal(computeLensRadius(0), 108);
});

test('shouldHideTouchLens toggles off only when tapping near active spotlight', () => {
  assert.equal(shouldHideTouchLens(false, { x: 100, y: 100 }, { x: 100, y: 100 }), false);
  assert.equal(shouldHideTouchLens(true, { x: 100, y: 100 }, { x: 112, y: 110 }), true);
  assert.equal(shouldHideTouchLens(true, { x: 100, y: 100 }, { x: 260, y: 240 }), false);
});
