import React from 'react';
import tealBlueNebulaImg from '../assets/images/teal_blue_nebula_1794604639109.jpg';

export default function AboutNebulaReveal() {
  return (
    <div
      aria-hidden="true"
      data-testid="about-nebula-layer"
      className="pointer-events-none absolute inset-0 z-0 overflow-hidden bg-[#000000]"
    >
      {/* Subdued, dimmed blue-green cosmic nebula ("meio apagada") */}
      <img
        src={tealBlueNebulaImg}
        alt=""
        referrerPolicy="no-referrer"
        draggable={false}
        className="w-full h-full object-cover object-center opacity-55 brightness-90 contrast-115 select-none"
      />

      {/* Organic deep black shadow pools & edge vignettes over the nebula */}
      <div
        className="absolute inset-0"
        style={{
          background: [
            'linear-gradient(to bottom, #000000 0%, rgba(0,0,0,0.45) 18%, rgba(0,0,0,0.28) 50%, rgba(0,0,0,0.52) 82%, #000000 100%)',
            'radial-gradient(ellipse 46% 52% at 14% 26%, rgba(0,0,0,0.92) 0%, rgba(0,0,0,0.55) 55%, rgba(0,0,0,0) 100%)',
            'radial-gradient(ellipse 48% 54% at 86% 74%, rgba(0,0,0,0.94) 0%, rgba(0,0,0,0.58) 52%, rgba(0,0,0,0) 100%)',
            'radial-gradient(ellipse 42% 40% at 82% 20%, rgba(0,0,0,0.86) 0%, rgba(0,0,0,0) 78%)',
            'radial-gradient(ellipse 45% 44% at 18% 82%, rgba(0,0,0,0.88) 0%, rgba(0,0,0,0) 78%)',
            'radial-gradient(ellipse 72% 70% at 50% 50%, rgba(0,0,0,0.18) 0%, rgba(0,0,0,0.72) 100%)',
          ].join(', '),
        }}
      />
    </div>
  );
}
