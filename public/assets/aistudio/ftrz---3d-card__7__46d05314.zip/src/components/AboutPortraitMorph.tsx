import React, { useRef, useState } from 'react';
import {
  clampLensPoint,
  computeLensRadius,
  LensPoint,
  shouldHideTouchLens,
} from './about-morph';

const ANA_CUTOUT_SRC = '/assets/ana-cutout.png';
const CATWOMAN_CUTOUT_SRC = '/assets/ana-catwoman.png';

export default function AboutPortraitMorph() {
  const stageRef = useRef<HTMLDivElement | null>(null);
  const [isLensActive, setIsLensActive] = useState(false);
  const [lensPos, setLensPos] = useState<LensPoint>({ x: 240, y: 220 });
  const [lensRadius, setLensRadius] = useState(112);
  const [anaBroken, setAnaBroken] = useState(false);
  const [catwomanBroken, setCatwomanBroken] = useState(false);

  const updateLensFromPointer = (clientX: number, clientY: number) => {
    const el = stageRef.current;
    if (!el) return null;
    const rect = el.getBoundingClientRect();
    const point = clampLensPoint(clientX, clientY, rect.left, rect.top, {
      width: rect.width,
      height: rect.height,
    });
    const radius = computeLensRadius(rect.width);
    el.style.setProperty('--lens-x', `${point.x}px`);
    el.style.setProperty('--lens-y', `${point.y}px`);
    el.style.setProperty('--lens-r', `${radius}px`);
    setLensPos(point);
    setLensRadius(radius);
    return point;
  };

  const handlePointerEnter = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.pointerType !== 'mouse') return;
    updateLensFromPointer(e.clientX, e.clientY);
    setIsLensActive(true);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.pointerType === 'mouse') {
      updateLensFromPointer(e.clientX, e.clientY);
      if (!isLensActive) setIsLensActive(true);
      return;
    }

    if (e.buttons > 0 || isLensActive) {
      updateLensFromPointer(e.clientX, e.clientY);
    }
  };

  const handlePointerLeave = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.pointerType !== 'mouse') return;
    setIsLensActive(false);
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.pointerType === 'mouse') return;
    const el = stageRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const tapped = clampLensPoint(e.clientX, e.clientY, rect.left, rect.top, {
      width: rect.width,
      height: rect.height,
    });

    if (shouldHideTouchLens(isLensActive, lensPos, tapped)) {
      setIsLensActive(false);
      return;
    }

    updateLensFromPointer(e.clientX, e.clientY);
    setIsLensActive(true);
  };

  const maskGradient = isLensActive
    ? `radial-gradient(circle var(--lens-r, ${lensRadius}px) at var(--lens-x, ${lensPos.x}px) var(--lens-y, ${lensPos.y}px), rgba(0,0,0,1) 0%, rgba(0,0,0,0.98) 52%, rgba(0,0,0,0.45) 78%, rgba(0,0,0,0) 100%)`
    : 'radial-gradient(circle 0px at 50% 50%, rgba(0,0,0,0) 0%, rgba(0,0,0,0) 100%)';

  return (
    <div className="relative flex flex-col items-center justify-end w-full">
      {/* 896x1200 aspect-locked borderless portrait stage matching pixel-aligned source assets */}
      <div
        ref={stageRef}
        onPointerEnter={handlePointerEnter}
        onPointerMove={handlePointerMove}
        onPointerLeave={handlePointerLeave}
        onPointerDown={handlePointerDown}
        role="img"
        aria-label="Retrato de Ana Carolina com revelação interativa do traje da Mulher-Gato sob o cursor"
        data-testid="about-portrait-morph"
        data-lens-active={isLensActive ? 'true' : 'false'}
        data-lens-pos={`${lensPos.x},${lensPos.y}`}
        className="relative w-full max-w-[420px] sm:max-w-[470px] lg:max-w-[500px] aspect-[896/1200] select-none cursor-crosshair touch-pan-y"
        style={{
          WebkitMaskImage:
            'linear-gradient(to bottom, #000000 0%, #000000 88%, rgba(0,0,0,0) 100%)',
          maskImage:
            'linear-gradient(to bottom, #000000 0%, #000000 88%, rgba(0,0,0,0) 100%)',
        }}
      >
        {/* Base portrait: Ana Carolina always visible */}
        {!anaBroken ? (
          <img
            src={ANA_CUTOUT_SRC}
            alt="Fotografia recortada de Ana Carolina"
            referrerPolicy="no-referrer"
            draggable={false}
            className="absolute inset-0 w-full h-full object-contain object-bottom pointer-events-none"
            onError={() => setAnaBroken(true)}
          />
        ) : (
          <div className="absolute inset-0 flex items-center justify-center text-sm text-slate-400">
            Ana Carolina
          </div>
        )}

        {/* Localized Catwoman costume revealed ONLY inside circular cursor spotlight */}
        {!catwomanBroken && (
          <div
            aria-hidden="true"
            className="absolute inset-0 pointer-events-none transition-opacity duration-150"
            style={{
              opacity: isLensActive ? 1 : 0,
              WebkitMaskImage: maskGradient,
              maskImage: maskGradient,
            }}
          >
            <img
              src={CATWOMAN_CUTOUT_SRC}
              alt=""
              referrerPolicy="no-referrer"
              draggable={false}
              className="w-full h-full object-contain object-bottom"
              onError={() => setCatwomanBroken(true)}
            />
          </div>
        )}
      </div>
    </div>
  );
}
