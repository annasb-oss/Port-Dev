import React from 'react';
import BandApp from './components/band/App';
import Navbar from './components/Navbar';
import AboutSection from './components/AboutSection';
import TechStackSection from './components/TechStackSection';
import Footer from './components/Footer';
import AuroraBackground from './components/AuroraBackground';
import PacmanDivider from './components/pacman/PacmanDivider';

export default function App() {
  return (
    <div className="relative w-full min-h-screen text-white overflow-x-hidden">
      {/* Dark night sky with moving Aurora Borealis and twinkling stars */}
      <AuroraBackground />

      {/* Sticky Navigation Bar */}
      <Navbar />

      {/* Hero Section: 3D Interactive Card Badge with Physics over solid vivid green background */}
      <section
        id="hero"
        aria-label="Apresentação 3D interativa"
        className="relative z-10 w-full h-screen min-h-[650px] overflow-hidden select-none bg-[#7CB342]"
      >
        {/* 3D Card Interactive Experience (Rapier Physics + Three.js Lanyard with transparent canvas) */}
        <BandApp />

        {/* Portfolio Welcome Text: only the title, clean and impactful */}
        <div className="pointer-events-none absolute inset-0 z-10 flex flex-col justify-end md:justify-center items-center md:items-start p-6 sm:p-10 md:p-16 lg:p-20 pb-16 md:pb-16">
          <div className="max-w-lg lg:max-w-xl text-center md:text-left">
            <h1 className="text-2xl sm:text-4xl md:text-5xl lg:text-6xl font-black tracking-tight text-white leading-tight uppercase font-sans drop-shadow-[0_4px_24px_rgba(0,0,0,0.45)]">
              BEM VINDO(A) AO MEU{' '}
              <span className="text-[#182D3B] drop-shadow-[0_2px_12px_rgba(255,255,255,0.22)]">
                PORTFOLIO
              </span>
              .
            </h1>
          </div>
        </div>
      </section>

      {/* Divisória interativa Pac-Man entre Início e Sobre Mim */}
      <PacmanDivider />

      {/* Seção Sobre Mim (Estudante de Programação com foco em Back-end + Post-its) */}
      <AboutSection />

      {/* Seção Conheça meus projetos + Pilha Técnica */}
      <TechStackSection />

      {/* Footer */}
      <Footer />
    </div>
  );
}
