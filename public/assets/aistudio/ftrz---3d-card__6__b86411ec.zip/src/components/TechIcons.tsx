import React from 'react';

interface IconProps {
  className?: string;
}

export function JavaIcon({ className = 'w-6 h-6' }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      {/* Steam lines */}
      <path d="M6 2c.5 1.5-1 2.5-.5 4" className="stroke-orange-400" />
      <path d="M10 1c.7 1.8-1.2 3-.5 5" className="stroke-orange-400" />
      <path d="M14 2c.5 1.5-1 2.5-.5 4" className="stroke-orange-400" />
      {/* Cup body */}
      <path d="M3 8h14v7a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4V8z" className="stroke-orange-400" fill="currentColor" fillOpacity="0.15" />
      {/* Cup handle */}
      <path d="M17 10h1.5a2.5 2.5 0 0 1 0 5H17" className="stroke-orange-400" />
      {/* Base plate */}
      <path d="M2 21h16" className="stroke-orange-400" />
    </svg>
  );
}

export function SpringIcon({ className = 'w-6 h-6' }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      {/* Spring leaf / sprout */}
      <path d="M12 2C6.5 2 2 6.5 2 12c0 3.8 2.2 7.1 5.4 8.7L18.5 9.6C16.9 5.3 12 2 12 2z" className="stroke-emerald-400" fill="currentColor" fillOpacity="0.15" />
      <path d="M7.4 20.7C8.8 21.5 10.3 22 12 22c5.5 0 10-4.5 10-10 0-1.7-.5-3.2-1.3-4.6L7.4 20.7z" className="stroke-emerald-400" fill="currentColor" fillOpacity="0.25" />
      <path d="M8 12c2.5 0 5-1.5 6-4" className="stroke-emerald-300" />
      <path d="M10 16c2-1 4-3 5-6" className="stroke-emerald-300" />
    </svg>
  );
}

export function PostgresIcon({ className = 'w-6 h-6' }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      {/* Relational database cylinder */}
      <ellipse cx="12" cy="5" rx="8" ry="3" className="stroke-blue-400" fill="currentColor" fillOpacity="0.15" />
      <path d="M4 5v6c0 1.66 3.58 3 8 3s8-1.34 8-3V5" className="stroke-blue-400" />
      <path d="M4 11v6c0 1.66 3.58 3 8 3s8-1.34 8-3v-6" className="stroke-blue-400" />
      <path d="M9 11l3 3 5-5" className="stroke-cyan-300" />
    </svg>
  );
}

export function MySqlIcon({ className = 'w-6 h-6' }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" className="stroke-sky-400" fill="currentColor" fillOpacity="0.1" />
      <path d="M6 10h12" className="stroke-sky-400" />
      <path d="M6 14h6" className="stroke-sky-400" />
      <circle cx="8" cy="7" r="1" fill="currentColor" className="text-sky-300" />
      <circle cx="11" cy="7" r="1" fill="currentColor" className="text-sky-300" />
      <circle cx="14" cy="7" r="1" fill="currentColor" className="text-sky-300" />
      <path d="M16 13l2 2 3-3" className="stroke-amber-400" />
    </svg>
  );
}

export function DockerIcon({ className = 'w-6 h-6' }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      {/* Container boxes stacked */}
      <rect x="2" y="8" width="4" height="3" rx="0.5" className="stroke-cyan-400" fill="currentColor" fillOpacity="0.2" />
      <rect x="7" y="8" width="4" height="3" rx="0.5" className="stroke-cyan-400" fill="currentColor" fillOpacity="0.2" />
      <rect x="12" y="8" width="4" height="3" rx="0.5" className="stroke-cyan-400" fill="currentColor" fillOpacity="0.2" />
      <rect x="7" y="4" width="4" height="3" rx="0.5" className="stroke-cyan-400" fill="currentColor" fillOpacity="0.2" />
      <rect x="12" y="4" width="4" height="3" rx="0.5" className="stroke-cyan-400" fill="currentColor" fillOpacity="0.2" />
      {/* Whale body base */}
      <path d="M1 12c.5 4 4.5 7 10.5 7 7.5 0 11.5-4 11.5-6.5 0-.5-.5-.5-1-.5-1 0-1.5.5-2.5.5s-2-.5-3.5-.5c-3 0-5 2-8 2-2 0-3.5-1-4.5-2z" className="stroke-cyan-400" fill="currentColor" fillOpacity="0.15" />
      <circle cx="18" cy="14" r="0.8" fill="currentColor" className="text-cyan-200" />
    </svg>
  );
}

export function JUnitIcon({ className = 'w-6 h-6' }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" className="stroke-rose-400" fill="currentColor" fillOpacity="0.15" />
      <path d="M8.5 12.5l2.5 2.5 5-5" className="stroke-emerald-400" strokeWidth="2.5" />
    </svg>
  );
}

export function TechIconRenderer({ iconName, className }: { iconName: string; className?: string }) {
  switch (iconName) {
    case 'java':
      return <JavaIcon className={className} />;
    case 'spring':
      return <SpringIcon className={className} />;
    case 'postgres':
      return <PostgresIcon className={className} />;
    case 'mysql':
      return <MySqlIcon className={className} />;
    case 'docker':
      return <DockerIcon className={className} />;
    case 'junit':
      return <JUnitIcon className={className} />;
    default:
      return null;
  }
}
