import React from 'react';
import { ABOUT_DATA, ABOUT_POST_ITS } from '../utils/portfolio-data';
import { GraduationCap, StickyNote } from 'lucide-react';

export default function AboutSection() {
  return (
    <section
      id="sobre-mim"
      className="relative z-10 w-full min-h-screen bg-[#F97316] px-4 sm:px-8 md:px-12 lg:px-16 py-16 md:py-24 text-white"
    >
      <div className="max-w-5xl mx-auto">
        {/* Section Header */}
        <div className="flex flex-col items-center md:items-start mb-12 md:mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-black/20 border border-white/30 text-white text-xs sm:text-sm font-semibold uppercase tracking-wider mb-4">
            <GraduationCap className="w-4 h-4 text-white" />
            <span>{ABOUT_DATA.role}</span>
          </div>

          <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-white uppercase font-sans drop-shadow-[0_2px_12px_rgba(0,0,0,0.28)]">
            Sobre <span className="text-[#7CB342]">Mim</span>
          </h2>
        </div>

        {/* Colorful Post-it Squares Grid (without photo or long text blocks) */}
        <div
          data-testid="about-postits-grid"
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-7 sm:gap-9"
        >
          {ABOUT_POST_ITS.map((note) => (
            <article
              key={note.id}
              data-testid={`postit-${note.id}`}
              className={`group relative aspect-square p-6 sm:p-7 rounded-sm rounded-br-3xl ${note.bgClass} ${note.tiltClass} text-zinc-900 shadow-[0_14px_30px_rgba(0,0,0,0.42)] hover:rotate-0 hover:-translate-y-2 hover:scale-[1.02] transition-all duration-300 flex flex-col justify-between`}
            >
              {/* Translucent sticky tape at the top center */}
              <div
                aria-hidden="true"
                className="pointer-events-none absolute -top-2.5 left-1/2 -translate-x-1/2 w-16 h-5 bg-white/45 backdrop-blur-[2px] border border-white/40 shadow-sm rotate-[-1deg]"
              />

              {/* Folded corner effect at bottom right */}
              <div
                aria-hidden="true"
                className="pointer-events-none absolute bottom-0 right-0 w-7 h-7 bg-gradient-to-tl from-black/20 via-black/5 to-transparent rounded-tl-lg"
              />

              {/* Top tag */}
              <div className="flex items-center justify-between gap-2 pt-2">
                <span
                  className={`inline-flex items-center px-2.5 py-1 rounded-md text-[11px] font-bold tracking-wider uppercase ${note.accentClass}`}
                >
                  {note.tag}
                </span>
                <StickyNote className="w-4 h-4 text-zinc-800/50 shrink-0" />
              </div>

              {/* Note Heading & Concise Summary */}
              <div className="my-auto py-3">
                <h3 className="text-xl sm:text-2xl font-extrabold tracking-tight text-zinc-950 mb-2">
                  {note.title}
                </h3>
                <p className="text-sm sm:text-base font-medium text-zinc-800 leading-snug">
                  {note.highlight}
                </p>
              </div>

              {/* Bottom subtle ruled line */}
              <div className="pt-3 border-t border-black/10 flex items-center justify-between text-[11px] font-semibold uppercase tracking-wider text-zinc-700/80">
                <span>Back-end Note</span>
                <span>•</span>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
