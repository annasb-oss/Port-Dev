import React from 'react';
import { PROJECTS, TECH_STACK } from '../utils/portfolio-data';
import { TechIconRenderer } from './TechIcons';
import { ShieldCheck, Cpu, FolderGit2, GraduationCap, ExternalLink, BookOpen } from 'lucide-react';

function GitHubMark({ className = 'w-5 h-5' }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="currentColor"
      aria-hidden="true"
      className={className}
    >
      <path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0 0 24 12c0-6.63-5.37-12-12-12Z" />
    </svg>
  );
}

export default function TechStackSection() {
  return (
    <section
      id="portfolio"
      className="relative z-10 w-full bg-black px-4 sm:px-8 md:px-12 lg:px-16 py-16 md:py-24 text-white scroll-mt-20"
    >
      <div className="max-w-6xl mx-auto">
        {/* Section Header */}
        <div className="flex flex-col items-center text-center mb-12 md:mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-400 text-xs sm:text-sm font-semibold uppercase tracking-wider mb-4">
            <FolderGit2 className="w-4 h-4 text-blue-400" />
            <span>Repositórios GitHub</span>
          </div>

          <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-white uppercase font-sans">
            Conheça <span className="text-[#3b82f6] drop-shadow-[0_0_20px_rgba(59,130,246,0.35)]">meus projetos</span>
          </h2>
          <p className="mt-3 text-base sm:text-lg text-zinc-400 max-w-2xl">
            Confira meus repositórios no GitHub e projetos desenvolvidos ao longo da minha jornada de estudos.
          </p>
        </div>

        {/* GitHub Projects Grid */}
        <div
          className={
            PROJECTS.length === 1
              ? 'max-w-md mx-auto mb-16'
              : 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16'
          }
        >
          {PROJECTS.map((project) => (
            <article
              key={project.id}
              data-testid={`project-${project.id}`}
              className="group relative p-6 rounded-3xl bg-[#141414] border border-zinc-800/90 hover:border-[#A51C30]/70 transition-all duration-300 shadow-lg hover:shadow-[0_10px_30px_rgba(165,28,48,0.16)] flex flex-col justify-between"
            >
              <div>
                {/* Top row: GitHub icon + Harvard study indicator */}
                <div className="flex items-center justify-between gap-2 mb-5">
                  <div className="w-12 h-12 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center text-white group-hover:scale-105 group-hover:border-zinc-700 transition duration-300 shrink-0">
                    <GitHubMark className="w-6 h-6" />
                  </div>

                  {/* Sinal de estudo com Harvard */}
                  <div
                    data-testid="harvard-study-signal"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#A51C30]/20 border border-[#A51C30]/55 text-rose-200 text-xs font-semibold"
                  >
                    <span className="w-2 h-2 rounded-full bg-[#ff4d67] animate-pulse" aria-hidden="true" />
                    <GraduationCap className="w-3.5 h-3.5 text-rose-300 shrink-0" />
                    <span>{project.studyLabel} • {project.institution}</span>
                  </div>
                </div>

                {/* Project Title */}
                <h3 className="text-xl font-bold text-white group-hover:text-blue-400 transition mb-1">
                  {project.title}
                </h3>

                {/* Repo Path */}
                <div className="flex items-center gap-1.5 text-xs font-mono text-zinc-400 mb-3 break-all">
                  <BookOpen className="w-3.5 h-3.5 text-[#ff4d67] shrink-0" />
                  <span>{project.repoPath}</span>
                </div>

                {/* Description */}
                <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed">
                  {project.description}
                </p>
              </div>

              {/* Direct GitHub Link */}
              <div className="mt-6 pt-4 border-t border-zinc-800/70">
                <a
                  href={project.repoUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={`Abrir repositório ${project.repoPath} no GitHub`}
                  className="inline-flex items-center justify-between gap-2 w-full px-4 py-2.5 rounded-2xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-700/80 hover:border-blue-500/60 text-xs sm:text-sm font-semibold text-white transition"
                >
                  <span className="inline-flex items-center gap-2">
                    <GitHubMark className="w-4 h-4 text-zinc-300 shrink-0" />
                    <span>Abrir repositório no GitHub</span>
                  </span>
                  <ExternalLink className="w-4 h-4 text-blue-400 shrink-0" />
                </a>
              </div>
            </article>
          ))}
        </div>

        {/* Pilha Técnica Sub-section */}
        <div id="pilha-tecnica" className="scroll-mt-24 pt-12 border-t border-zinc-900">
          <div className="flex flex-col items-center text-center mb-10">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-400 text-xs sm:text-sm font-semibold uppercase tracking-wider mb-3">
              <Cpu className="w-4 h-4 text-blue-400" />
              <span>Ferramentas & Tecnologias</span>
            </div>
            <h3 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white uppercase font-sans">
              Tecnologias <span className="text-[#3b82f6]">Back-end</span>
            </h3>
            <p className="mt-2 text-sm sm:text-base text-zinc-400 max-w-2xl">
              As tecnologias fundamentais que utilizo no desenvolvimento e nos estudos diários de back-end.
            </p>
          </div>

          {/* Tech Stack Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {TECH_STACK.map((tech) => (
              <div
                key={tech.id}
                className="group relative p-6 rounded-3xl bg-[#141414] border border-zinc-800/90 hover:border-blue-500/50 transition-all duration-300 shadow-lg hover:shadow-[0_10px_30px_rgba(59,130,246,0.12)] flex flex-col justify-between"
              >
                <div>
                  {/* Header with icon and level pill */}
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center p-2.5 group-hover:scale-110 group-hover:border-zinc-700 transition duration-300">
                      <TechIconRenderer iconName={tech.iconName} className="w-7 h-7" />
                    </div>
                    <span
                      className={`text-xs px-2.5 py-1 rounded-full font-medium border ${tech.badgeColor}`}
                    >
                      {tech.level}
                    </span>
                  </div>

                  {/* Tech Title & Optional Alias */}
                  <div className="mb-2">
                    <h4 className="text-xl font-bold text-white group-hover:text-blue-400 transition">
                      {tech.name}
                    </h4>
                    {tech.alias && (
                      <span className="text-xs font-semibold text-zinc-500 block mt-0.5">
                        ({tech.alias})
                      </span>
                    )}
                  </div>

                  {/* Category tag */}
                  <span className="text-xs text-blue-400/90 font-medium uppercase tracking-wider block mb-3">
                    {tech.category}
                  </span>

                  {/* Description */}
                  <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed">
                    {tech.description}
                  </p>
                </div>

                {/* Bottom indicator */}
                <div className="mt-6 pt-4 border-t border-zinc-800/60 flex items-center justify-between text-xs text-zinc-500">
                  <span className="flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    Boas Práticas
                  </span>
                  <span className="text-zinc-600 font-mono text-[10px]">BACKEND-STACK</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
