import * as THREE from 'three';

/**
 * Calculates adaptive lerp speed based on distance between previous and current joint positions.
 */
export function calculateLerpSpeed(
  distance: number,
  minSpeed: number = 10,
  maxSpeed: number = 50
): number {
  const clampedDistance = Math.max(0.1, Math.min(1, distance));
  return minSpeed + clampedDistance * (maxSpeed - minSpeed);
}

/**
 * Calculates restorative angular velocity to keep the card facing forward towards the camera.
 */
export function calculateRestorativeAngVel(
  angVel: { x: number; y: number; z: number },
  rotY: number,
  restorativeFactor: number = 0.25
): { x: number; y: number; z: number } {
  return {
    x: angVel.x,
    y: angVel.y - rotY * restorativeFactor,
    z: angVel.z,
  };
}

/**
 * Computes unprojected 3D drag destination from normalized pointer coordinates.
 */
export function computeDragDestination(
  pointerX: number,
  pointerY: number,
  cameraZ: number,
  dragOffset: { x: number; y: number; z: number }
): { x: number; y: number; z: number } {
  const fovFactor = Math.tan((25 * Math.PI) / 360);
  const targetX = pointerX * cameraZ * fovFactor;
  const targetY = pointerY * cameraZ * fovFactor;
  return {
    x: targetX - dragOffset.x,
    y: targetY - dragOffset.y,
    z: 0 - dragOffset.z,
  };
}

/**
 * Evaluates points along a 4-point CatmullRom spline for the lanyard ribbon.
 */
export function generateLanyardCurvePoints(
  p0: THREE.Vector3,
  p1: THREE.Vector3,
  p2: THREE.Vector3,
  p3: THREE.Vector3,
  sampleCount: number = 32
): THREE.Vector3[] {
  const curve = new THREE.CatmullRomCurve3([p0, p1, p2, p3], false, 'chordal');
  return curve.getPoints(sampleCount);
}
