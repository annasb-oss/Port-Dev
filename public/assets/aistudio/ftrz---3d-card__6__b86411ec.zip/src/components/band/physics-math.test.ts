import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import {
  calculateLerpSpeed,
  calculateRestorativeAngVel,
  generateLanyardCurvePoints,
} from './physics-math';

test('calculateLerpSpeed clamps between minSpeed and maxSpeed', () => {
  // distance below 0.1 clamps to 0.1
  const speedAtZero = calculateLerpSpeed(0, 10, 50);
  assert.equal(speedAtZero, 10 + 0.1 * 40); // 14

  // distance at 0.5
  const speedAtHalf = calculateLerpSpeed(0.5, 10, 50);
  assert.equal(speedAtHalf, 10 + 0.5 * 40); // 30

  // distance at or above 1 clamps to 1
  const speedAtOne = calculateLerpSpeed(1, 10, 50);
  assert.equal(speedAtOne, 50);

  const speedAtHigh = calculateLerpSpeed(5, 10, 50);
  assert.equal(speedAtHigh, 50);
});

test('calculateRestorativeAngVel applies restorative torque on yaw (Y)', () => {
  const angVel = { x: 1, y: 2, z: 0.5 };
  const rotY = 0.8;
  const result = calculateRestorativeAngVel(angVel, rotY, 0.25);
  assert.equal(result.x, 1);
  assert.equal(result.y, 2 - 0.8 * 0.25); // 1.8
  assert.equal(result.z, 0.5);
});

test('generateLanyardCurvePoints returns requested number of sample points', () => {
  const p0 = new THREE.Vector3(0, 4, 0);
  const p1 = new THREE.Vector3(0.5, 2.5, 0);
  const p2 = new THREE.Vector3(1, 1, 0);
  const p3 = new THREE.Vector3(1.5, 0, 0);
  const samples = generateLanyardCurvePoints(p0, p1, p2, p3, 32);

  // getPoints(32) returns 33 points (0 to 32 inclusive)
  assert.equal(samples.length, 33);
  assert.ok(samples[0].equals(p0));
  assert.ok(samples[samples.length - 1].equals(p3));
});
