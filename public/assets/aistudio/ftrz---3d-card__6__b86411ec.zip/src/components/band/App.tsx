import './index.css';
import * as THREE from 'three';
import { Suspense, useEffect, useRef, useState, useMemo } from 'react';
import { Canvas, extend, useThree, useFrame } from '@react-three/fiber';
import { useGLTF, useTexture, Environment, Lightformer } from '@react-three/drei';
import {
  BallCollider,
  CuboidCollider,
  Physics,
  RigidBody,
  useRopeJoint,
  useSphericalJoint,
  type RapierRigidBody,
} from '@react-three/rapier';
import { MeshLineGeometry, MeshLineMaterial } from 'meshline';

extend({ MeshLineGeometry, MeshLineMaterial });

const GLTF_PATH = '/assets/kartu.glb';
const TEXTURE_PATH = '/assets/bandd.png';
const CARD_TEXTURE_PATH = '/assets/card_texture_custom.png?v=5';

useGLTF.preload(GLTF_PATH);
useTexture.preload(TEXTURE_PATH);
useTexture.preload(CARD_TEXTURE_PATH);

export default function App() {
  return (
    <div className="responsive-wrapper" data-testid="3d-card-wrapper">
      <Canvas
        camera={{ position: [0, 0, 13], fov: 25 }}
        gl={{ antialias: true, alpha: true }}
      >
        <ambientLight intensity={1.0} />
        <Suspense fallback={null}>
          <Physics interpolate gravity={[0, -40, 0]} timeStep={1 / 60}>
            <Band />
          </Physics>
          <Environment blur={0.75}>
            <Lightformer
              intensity={1.2}
              color="white"
              position={[0, -1, 5]}
              rotation={[0, 0, Math.PI / 3]}
              scale={[100, 0.1, 1]}
            />
            <Lightformer
              intensity={1.5}
              color="white"
              position={[-1, -1, 1]}
              rotation={[0, 0, Math.PI / 3]}
              scale={[100, 0.1, 1]}
            />
            <Lightformer
              intensity={1.5}
              color="white"
              position={[1, 1, 1]}
              rotation={[0, 0, Math.PI / 3]}
              scale={[100, 0.1, 1]}
            />
            <Lightformer
              intensity={3.5}
              color="white"
              position={[-10, 0, 14]}
              rotation={[0, Math.PI / 2, Math.PI / 3]}
              scale={[100, 10, 1]}
            />
          </Environment>
        </Suspense>
      </Canvas>
    </div>
  );
}

interface BandProps {
  maxSpeed?: number;
  minSpeed?: number;
}

function Band({ maxSpeed = 50, minSpeed = 10 }: BandProps) {
  const band = useRef<THREE.Mesh<any, any>>(null!);
  const fixed = useRef<RapierRigidBody>(null!);
  const j1 = useRef<RapierRigidBody & { lerped?: THREE.Vector3 }>(null!);
  const j2 = useRef<RapierRigidBody & { lerped?: THREE.Vector3 }>(null!);
  const j3 = useRef<RapierRigidBody>(null!);
  const card = useRef<RapierRigidBody>(null!);

  const vec = useMemo(() => new THREE.Vector3(), []);
  const ang = useMemo(() => new THREE.Vector3(), []);
  const rot = useMemo(() => new THREE.Vector3(), []);
  const dir = useMemo(() => new THREE.Vector3(), []);

  const segmentProps = {
    type: 'dynamic' as const,
    canSleep: true,
    colliders: false as const,
    angularDamping: 4,
    linearDamping: 4,
  };

  const { nodes, materials } = useGLTF(GLTF_PATH) as any;
  const texture = useTexture(TEXTURE_PATH);
  const cardTexture = useTexture(CARD_TEXTURE_PATH);

  useMemo(() => {
    cardTexture.flipY = false;
    cardTexture.colorSpace = THREE.SRGBColorSpace;
    cardTexture.needsUpdate = true;
  }, [cardTexture]);

  const { width, height } = useThree((state) => state.size);
  const isMobile = width < 768;
  const anchorX = isMobile ? 0 : 2.35;

  const [curve] = useState(
    () =>
      new THREE.CatmullRomCurve3([
        new THREE.Vector3(),
        new THREE.Vector3(),
        new THREE.Vector3(),
        new THREE.Vector3(),
      ])
  );

  const [dragged, drag] = useState<THREE.Vector3 | false>(false);
  const [hovered, hover] = useState(false);

  useRopeJoint(fixed, j1, [[0, 0, 0], [0, 0, 0], 1]);
  useRopeJoint(j1, j2, [[0, 0, 0], [0, 0, 0], 1]);
  useRopeJoint(j2, j3, [[0, 0, 0], [0, 0, 0], 1]);
  useSphericalJoint(j3, card, [[0, 0, 0], [0, 1.84, 0]]);

  useEffect(() => {
    if (hovered) {
      document.body.style.cursor = dragged ? 'grabbing' : 'grab';
    } else {
      document.body.style.cursor = 'auto';
    }
    return () => {
      document.body.style.cursor = 'auto';
    };
  }, [hovered, dragged]);

  useEffect(() => {
    const handleGlobalPointerUp = () => {
      drag(false);
    };
    window.addEventListener('pointerup', handleGlobalPointerUp);
    return () => {
      window.removeEventListener('pointerup', handleGlobalPointerUp);
    };
  }, []);

  useFrame((state, delta) => {
    if (dragged && card.current) {
      vec.set(state.pointer.x, state.pointer.y, 0.5).unproject(state.camera);
      dir.copy(vec).sub(state.camera.position).normalize();
      vec.add(dir.multiplyScalar(state.camera.position.length()));
      [card, j1, j2, j3, fixed].forEach((ref) => ref.current?.wakeUp());
      card.current.setNextKinematicTranslation({
        x: vec.x - dragged.x,
        y: vec.y - dragged.y,
        z: vec.z - dragged.z,
      });
    }

    if (
      fixed.current &&
      j1.current &&
      j2.current &&
      j3.current &&
      card.current &&
      band.current?.geometry
    ) {
      const safeDelta = Math.min(delta, 0.05);

      [j1, j2].forEach((ref) => {
        if (!ref.current) return;
        const currentPos = ref.current.translation();
        if (!Number.isFinite(currentPos.x)) return;

        if (!ref.current.lerped) {
          ref.current.lerped = new THREE.Vector3(currentPos.x, currentPos.y, currentPos.z);
        }

        const clampedDistance = Math.max(
          0.1,
          Math.min(1, ref.current.lerped.distanceTo(currentPos))
        );
        const alpha = Math.min(
          1,
          safeDelta * (minSpeed + clampedDistance * (maxSpeed - minSpeed))
        );
        ref.current.lerped.lerp(currentPos, alpha);
      });

      const j3Pos = j3.current?.translation();
      const fixedPos = fixed.current?.translation();

      if (j3Pos && Number.isFinite(j3Pos.x) && fixedPos && Number.isFinite(fixedPos.x)) {
        curve.points[0].copy(j3Pos);
        if (j2.current?.lerped) curve.points[1].copy(j2.current.lerped);
        if (j1.current?.lerped) curve.points[2].copy(j1.current.lerped);
        curve.points[3].copy(fixedPos);
        band.current.geometry.setPoints(curve.getPoints(32));
      }

      if (!dragged) {
        const currentAngvel = card.current.angvel();
        const currentRotation = card.current.rotation();
        if (
          currentAngvel &&
          Number.isFinite(currentAngvel.x) &&
          currentRotation &&
          Number.isFinite(currentRotation.y)
        ) {
          ang.copy(currentAngvel);
          rot.copy(currentRotation);
          card.current.setAngvel(
            { x: ang.x, y: ang.y - rot.y * 0.25, z: ang.z },
            true
          );
        }
      }
    }
  });

  curve.curveType = 'chordal';
  texture.wrapS = texture.wrapT = THREE.RepeatWrapping;

  return (
    <>
      <group position={[anchorX, 4, 0]}>
        <RigidBody ref={fixed} {...segmentProps} type="fixed" />
        <RigidBody position={[0.5, 0, 0]} ref={j1} {...segmentProps}>
          <BallCollider args={[0.1]} />
        </RigidBody>
        <RigidBody position={[1, 0, 0]} ref={j2} {...segmentProps}>
          <BallCollider args={[0.1]} />
        </RigidBody>
        <RigidBody position={[1.5, 0, 0]} ref={j3} {...segmentProps}>
          <BallCollider args={[0.1]} />
        </RigidBody>
        <RigidBody
          position={[2, 0, 0]}
          ref={card}
          {...segmentProps}
          type={dragged ? 'kinematicPosition' : 'dynamic'}
        >
          <CuboidCollider args={[1.01, 1.43, 0.01]} />
          <group
            scale={2.85}
            position={[0, -1.52, -0.05]}
            onPointerOver={() => hover(true)}
            onPointerOut={() => hover(false)}
            onPointerUp={(e: any) => {
              try {
                e.target?.releasePointerCapture?.(e.pointerId);
              } catch {}
              try {
                e.nativeEvent?.target?.releasePointerCapture?.(e.pointerId);
              } catch {}
              drag(false);
            }}
            onPointerDown={(e: any) => {
              e.stopPropagation();
              try {
                e.target?.setPointerCapture?.(e.pointerId);
              } catch {}
              try {
                e.nativeEvent?.target?.setPointerCapture?.(e.pointerId);
              } catch {}
              if (card.current && e?.point) {
                const trans = card.current.translation();
                if (Number.isFinite(trans.x)) {
                  drag(new THREE.Vector3().copy(e.point).sub(trans));
                }
              }
            }}
          >
            <mesh geometry={nodes.card.geometry}>
              <meshPhysicalMaterial
                map={cardTexture}
                map-anisotropy={16}
                clearcoat={0.08}
                clearcoatRoughness={0.2}
                roughness={0.3}
                metalness={0.0}
                envMapIntensity={0.55}
                side={THREE.DoubleSide}
              />
            </mesh>
            <mesh
              geometry={nodes.clip.geometry}
              material={materials.metal}
              material-roughness={0.3}
            />
            <mesh geometry={nodes.clamp.geometry} material={materials.metal} />
          </group>
        </RigidBody>
      </group>
      <mesh ref={band}>
        <meshLineGeometry />
        <meshLineMaterial
          color="white"
          depthTest={false}
          resolution={[width, height]}
          useMap
          map={texture}
          repeat={[-4, 1]}
          lineWidth={1}
        />
      </mesh>
    </>
  );
}
