import test from 'node:test';
import assert from 'node:assert/strict';
import {
  GAME_MAX_X,
  GAME_MIN_X,
  createInitialGameState,
  findNearestUneatenPellet,
  stepGameState,
} from './pacman-game';

test('Pac-Man moves and collects pellets along the track', () => {
  const state = createInitialGameState(12);
  const initialRemaining = state.pellets.filter((p) => !p.eaten).length;
  assert.equal(initialRemaining, 12);

  // Move Pac-Man right across several frames
  for (let i = 0; i < 120; i++) {
    stepGameState(state, 0.03);
  }

  const afterRemaining = state.pellets.filter((p) => !p.eaten).length;
  assert.ok(afterRemaining < initialRemaining, 'Pac-Man should consume pellets');
});

test('Pac-Man stays within track bounds and dodges approaching ghost', () => {
  const state = createInitialGameState(10);
  state.pacman.x = 0.4;
  state.pacman.dir = 1;
  // Place pink ghost directly ahead within danger distance
  state.ghosts[0].x = 0.46;
  state.ghosts[0].dir = -1;
  // Place blue ghost far away
  state.ghosts[1].x = 0.9;

  stepGameState(state, 0.02);

  assert.equal(state.pacman.dir, -1, 'Pac-Man should reverse to dodge ghost ahead');
  assert.ok(state.pacman.x >= GAME_MIN_X && state.pacman.x <= GAME_MAX_X);
});

test('Ghosts stay within bounds and move independently', () => {
  const state = createInitialGameState(10);
  const startBlueX = state.ghosts[1].x;
  const startPinkX = state.ghosts[0].x;

  for (let i = 0; i < 80; i++) {
    stepGameState(state, 0.03);
    for (const g of state.ghosts) {
      assert.ok(g.x >= GAME_MIN_X && g.x <= GAME_MAX_X);
    }
  }

  assert.notEqual(state.ghosts[0].x, startPinkX);
  assert.notEqual(state.ghosts[1].x, startBlueX);
});

test('Collision triggers brief invulnerability cooldown without crashing', () => {
  const state = createInitialGameState(8);
  state.pacman.x = 0.5;
  state.pacman.dodgeHopY = 0;
  state.ghosts[0].x = 0.505;
  state.ghosts[1].x = 0.9;

  stepGameState(state, 0.016);
  assert.ok(state.pacman.invulnerableTimer > 0, 'Collision should grant brief invulnerability');
});

test('Clearing all pellets triggers round reset and respawns pellets', () => {
  const state = createInitialGameState(6);
  for (const p of state.pellets) {
    p.eaten = true;
  }

  let sawFullRespawn = false;
  for (let i = 0; i < 40; i++) {
    stepGameState(state, 0.03);
    const uneaten = state.pellets.filter((p) => !p.eaten).length;
    if (uneaten === 6) {
      sawFullRespawn = true;
      break;
    }
  }

  assert.equal(sawFullRespawn, true, 'All pellets should respawn after course is cleared');
});

test('findNearestUneatenPellet returns closest remaining pellet', () => {
  const state = createInitialGameState(5);
  state.pellets[0].eaten = true;
  state.pellets[1].eaten = true;
  const nearest = findNearestUneatenPellet(0.5, state.pellets);
  assert.ok(nearest !== null && !nearest.eaten);
});
