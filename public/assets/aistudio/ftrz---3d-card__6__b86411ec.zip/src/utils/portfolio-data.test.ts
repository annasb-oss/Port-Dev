import test from 'node:test';
import assert from 'node:assert/strict';
import {
  TECH_STACK,
  ABOUT_DATA,
  ABOUT_POST_ITS,
  PROJECTS,
  validateTechStackRequirements,
  getTechStackById,
} from './portfolio-data';

test('TECH_STACK contains all requested technologies', () => {
  assert.equal(validateTechStackRequirements(), true);

  const java = getTechStackById('java');
  assert.ok(java);
  assert.equal(java?.name, 'Java');

  const spring = getTechStackById('spring-boot');
  assert.ok(spring);
  assert.equal(spring?.alias, 'Bota Primavera');

  const postgres = getTechStackById('postgresql');
  assert.ok(postgres);
  assert.equal(postgres?.name, 'PostgreSQL');

  const mysql = getTechStackById('mysql');
  assert.ok(mysql);
  assert.equal(mysql?.name, 'MySQL');

  const docker = getTechStackById('docker');
  assert.ok(docker);
  assert.equal(docker?.alias, 'Estivador');

  const junit = getTechStackById('junit');
  assert.ok(junit);
  assert.equal(junit?.name, 'JUnit');
});

test('ABOUT_DATA includes backend student profile and photo path', () => {
  assert.match(ABOUT_DATA.role, /Estudante de Programação/);
  assert.match(ABOUT_DATA.focus, /Back-end/i);
  assert.ok(ABOUT_DATA.photoUrl.includes('WhatsApp_Image_2026-11-12_at_14.43.43_ad621477.jpeg'));
  assert.ok(ABOUT_DATA.bioParagraphs.length >= 2);
  assert.ok(ABOUT_DATA.pillars.length >= 4);
});

test('ABOUT_POST_ITS provides colorful square notes for About section', () => {
  assert.equal(ABOUT_POST_ITS.length, 6);
  const colors = new Set(ABOUT_POST_ITS.map((item) => item.bgClass));
  assert.equal(colors.size, 6);
});

test('PROJECTS includes GitHub repository adivinhe-o-numero with Harvard study indicator', () => {
  const repo = PROJECTS.find((p) => p.id === 'adivinhe-o-numero');
  assert.ok(repo);
  assert.equal(repo?.repoUrl, 'https://github.com/annasb-oss/adivinhe-o-numero');
  assert.equal(repo?.institution, 'Harvard');
  assert.match(repo?.studyLabel ?? '', /estudo/i);
});
